# Express.js REST API Mini Project

## Overview
This is a simple RESTful API built with Express.js. It demonstrates basic CRUD operations with proper routing, validation, and error handling.

## Features
- Express.js setup with middleware
- Root route returns "Hello, World!"
- CRUD operations on `/items`
- In-memory data storage (array)
- Input validation and meaningful error responses

## Setup Instructions

### Prerequisites
- Node.js (v14 or higher)
- npm

### Installation

```bash
git clone <repo-url>  # or unzip the folder
cd refined-express-api
npm install
```

### Running the API

```bash
npm start
```
The API will run at: `http://localhost:3000`

## API Endpoints

### GET `/`
Returns a welcome message.
```json
"Hello, World!"
```

### GET `/items`
Returns all items.

### GET `/items/:id`
Returns a single item by ID.

### POST `/items`
Creates a new item.

**Body:**
```json
{
  "name": "Sample Item",
  "description": "This is a sample description"
}
```

### PUT `/items/:id`
Updates an existing item by ID.

**Body:**
```json
{
  "name": "Updated Name",
  "description": "Updated description"
}
```

### DELETE `/items/:id`
Deletes an item by ID.

## Example Requests

**POST /items**
```bash
curl -X POST http://localhost:3000/items -H "Content-Type: application/json" -d '{"name": "Test Item", "description": "This is a test."}'
```

**GET /items**
```bash
curl http://localhost:3000/items
```

**GET /items/:id**
```bash
curl http://localhost:3000/items/<id>
```

**PUT /items/:id**
```bash
curl -X PUT http://localhost:3000/items/<id> -H "Content-Type: application/json" -d '{"name": "Updated", "description": "Updated description"}'
```

**DELETE /items/:id**
```bash
curl -X DELETE http://localhost:3000/items/<id>
```

## License
MIT