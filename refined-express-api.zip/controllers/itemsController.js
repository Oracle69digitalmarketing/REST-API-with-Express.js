const { v4: uuidv4 } = require('uuid');
let items = [];

exports.getItems = (req, res) => res.json(items);

exports.getItemById = (req, res) => {
  const item = items.find(i => i.id === req.params.id);
  if (!item) return res.status(404).json({ error: `Item with ID ${req.params.id} not found` });
  res.json(item);
};

exports.createItem = (req, res) => {
  const { name, description } = req.body;
  const newItem = { id: uuidv4(), name, description };
  items.push(newItem);
  res.status(201).json(newItem);
};

exports.updateItem = (req, res) => {
  const index = items.findIndex(i => i.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: `Item with ID ${req.params.id} not found` });
  const { name, description } = req.body;
  items[index] = { ...items[index], name, description };
  res.json(items[index]);
};

exports.deleteItem = (req, res) => {
  const index = items.findIndex(i => i.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: `Item with ID ${req.params.id} not found` });
  const deleted = items.splice(index, 1);
  res.json({ message: 'Item deleted', item: deleted[0] });
};